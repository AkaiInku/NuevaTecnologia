var acumulado = "";

function mostrarYAcumular() {
    var seleccion = document.getElementById("seleccion");
    var cantidad = document.getElementById("cantidad").value;
    var resultado = document.getElementById("resultado");
    var eleccion = seleccion.value;
    var lista = {
        "maiz": "verdura",
        "kiwi": "fruta",
        "manzana": "fruta",
        "melocoton": "fruta",
        "remolacha": "verdura",
        "pepino": "verdura",
        "fresas": "fruta",
        "aguacate": "fruta",
        "cereza": "fruta"
    };

    if (lista.hasOwnProperty(eleccion)) {
        acumulado += cantidad + " " + eleccion + " = " + lista[eleccion] + ", ";
        resultado.textContent = acumulado;
    } else {
        resultado.textContent = "Por favor, selecciona una opción válida.";
    }
}