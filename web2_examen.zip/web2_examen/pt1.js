// Definir los arreglos
const arreglo1 = [3, 5, 9, 10, 35, 42, 12, 22, 25];
const arreglo2 = [9, 5, 33, 12, 7, 20, 22, 3, 8];

// Obtener la referencia al tbody de la tabla
const tablaBody = document.getElementById('tablaBody');

// Inicializar las variables para almacenar los totales
let totalArreglo1 = 0;
let totalArreglo2 = 0;

// Crear filas para la tabla y calcular los totales
for (let i = 0; i < arreglo1.length; i++) {
    const fila = document.createElement('tr');
    const suma = arreglo1[i] + arreglo2[i];
    totalArreglo1 += arreglo1[i];
    totalArreglo2 += arreglo2[i];

    fila.innerHTML = `
        <td>${arreglo1[i]}</td>
        <td>${arreglo2[i]}</td>
        <td>${suma}</td>
    `;

    tablaBody.appendChild(fila);
}

// Actualizar los totales en la página
document.getElementById('totalArreglo1').textContent = totalArreglo1;
document.getElementById('totalArreglo2').textContent = totalArreglo2;
document.getElementById('totalGlobal').textContent = totalArreglo1 + totalArreglo2;