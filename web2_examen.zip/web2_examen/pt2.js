const productos = [];


const formulario = document.getElementById('formulario');
const listaProductos = document.getElementById('listaProductos');
const totalSinIVAElement = document.getElementById('totalSinIVA');
const totalConIVAElement = document.getElementById('totalConIVA');


formulario.addEventListener('submit', function (event) {
    event.preventDefault(); 

   
    const nombre = document.getElementById('nombre').value;
    const precio = parseFloat(document.getElementById('precio').value);
    const cantidad = parseInt(document.getElementById('cantidad').value);

  
    productos.push({ nombre, precio, cantidad });

  
    const listItem = document.createElement('li');
    listItem.textContent = `${nombre} - Precio: $${precio.toFixed(2)} - Cantidad: ${cantidad}`;
    listaProductos.appendChild(listItem);

   
    let totalSinIVA = 0;
    for (const producto of productos) {
        totalSinIVA += producto.precio * producto.cantidad;
    }

   
    const iva = 0.16;
    const totalConIVA = totalSinIVA * (1 + iva);

    totalSinIVAElement.textContent = `$${totalSinIVA.toFixed(2)}`;
    totalConIVAElement.textContent = `$${totalConIVA.toFixed(2)}`;
});